import React from 'react';
import Dashboard from './Dashboard/Dashboard';

const App = () => (
  <>
    <Dashboard />
  </>
);

export default App;

// class App extends Component {
//   state = {};

//   render() {
//     return (
//       <>
//         <Dashboard />
//       </>
//     );
//   }
// }

// export default App;
